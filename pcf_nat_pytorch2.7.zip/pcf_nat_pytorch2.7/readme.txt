# PCF-NATransformer

# Currently, only NVIDIA GPUs with compute capability >= 8.0 are supported.
# It is recommended to have at least 24GB of GPU VRAM. If the VRAM is insufficient, you can set the embedding model to use checkpoints in the YAML file used for training.
# The supported data formats are: torch.bfloat16 and torch.float16.
# Voxceleb2, m4a -> wav: ffmpeg -y -i xx.m4a -ac 1 -vn -acodec pcm_s16le -ar 16000 xx.wav

NA operator support: pytorch 2.0~2.7.0
When using pytorch<2.6, mabe you need to change the train.py and evaluate.py( torch.autocast and torch.GradScaler).

1. install NA operator：
conda activate tc270
cd pcf_nat/extension_na/
pip install --no-build-isolation -e .

Although PyTorch comes with built-in support for CUDA and cuDNN, 
you still need to install CUDA 12.x separately and ensure that the NVCC command is available to compile and execute custom CUDA operators for neighborhood attention.

2. train steps:
a. Modify the yaml files in the folder './configs/'
    save_folder
    train_data_foler, musan_folder, simulated_rirs_folder
        our file directory structure:
            '/mnt/data_ext4/voxceleb/voxceleb2/wav/id00012/_raOc3-IRsw/00110.wav'
            '/mnt/data_ext4/musan/music/fma/music-fma-0000.wav'
            '/mnt/data_ext4/RIRS_NOISES/simulated_rirs/largeroom/Room001/Room001-00001.wav'

b. Execute command: python train_main.py --hparams_file=./configs/xx.yaml --epoch=0


3. evaluate steps:
a. Modify './public/EvaluateCall_pair.py'
    file path such as 'veri_test2.txt'
    the folder of voxceleb1
        our file directory structure: '/mnt/data_ext4/voxceleb/voxceleb1/wav/id10001/1zcIwhmdeo4/00001.wav'

b. Execute command: python evaluate_main.py --save_folder='./results/xx/' --epoch=10 --asnorm=True