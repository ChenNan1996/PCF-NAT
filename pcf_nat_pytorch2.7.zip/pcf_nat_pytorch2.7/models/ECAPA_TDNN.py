# --------------------------------------------------------
# reference: ECAPA-TDNN https://www.isca-archive.org/interspeech_2020/desplanques20_interspeech.html
# reference: SpeechBrain https://github.com/speechbrain/speechbrain

# PCF-NATransformer: https://arxiv.org/abs/2405.12031
# Written by Nian Li
# email: 1173417216@qq.com
# --------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from models.Modules import TDNNBlock, lens_to_mask_1d
from models.Pooling import AttentiveStatisticsPooling

class Res2NetBlock(torch.nn.Module):
    def __init__(
            self, in_channels, out_channels, scale=8, kernel_size=3, dilation=1
    ):
        super(Res2NetBlock, self).__init__()
        assert in_channels % scale == 0
        assert out_channels % scale == 0
        in_channel = in_channels // scale
        hidden_channel = out_channels // scale

        self.tdnns = nn.ModuleList()
        for i in range(scale - 1):
            self.tdnns.append(TDNNBlock(in_channel, hidden_channel, kernel_size, dilation=dilation))
        
        self.scale = scale

    def forward(self, x):
        y = []
        y1 = None
        for i, xi in enumerate(torch.chunk(x, self.scale, dim=1)):
            if i == 0:
                y.append(xi)
            else:
                if i == 1:
                    y1 = xi
                else:
                    y1 = y1 + xi
                y1 = self.tdnns[i-1](y1)
                y.append(y1)
        y = torch.cat(y, dim=1)
        return y
    
class SEBlock(nn.Module):
    def __init__(self, in_channels, se_channels, out_channels):
        super(SEBlock, self).__init__()
        self.fc1 = nn.Linear(in_features=in_channels, out_features=se_channels)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Linear(in_features=se_channels, out_features=out_channels)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, lens=None):
        if lens is not None:
            mask, lens_dot = lens_to_mask_1d(x.shape, lens)
            s = (x*mask).sum(dim=-1)/lens_dot.squeeze(-1)
        else:
            s = x.mean(dim=-1)
        s = self.relu(self.fc1(s))
        s = self.sigmoid(self.fc2(s))
        s = s.unsqueeze(-1)
        return s * x

    
class SERes2NetBlock(nn.Module):
    def __init__(
            self,
            in_channels,
            out_channels,
            res2net_scale=8,
            se_channels=128,
            kernel_size=1,
            dilation=1,
            activation=torch.nn.ReLU,
            groups=1,
    ):
        super().__init__()
        self.out_channels = out_channels
        self.tdnn1 = TDNNBlock(
            in_channels,
            out_channels,
            kernel_size=1,
            dilation=1,
            activation=activation,
            groups=groups,
        )
        self.res2net_block = Res2NetBlock(
            out_channels, out_channels, res2net_scale, kernel_size, dilation
        )
        self.tdnn2 = TDNNBlock(
            out_channels,
            out_channels,
            kernel_size=1,
            dilation=1,
            activation=activation,
            groups=groups,
        )
        self.se_block = SEBlock(out_channels, se_channels, out_channels)

        self.shortcut = None
        if in_channels != out_channels:
            self.shortcut = nn.Conv1d(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=1,
            )

    def forward(self, x, lens=None):
        residual = x if self.shortcut is None else self.shortcut(x)

        x = self.tdnn1(x)
        x = self.res2net_block(x)
        x = self.tdnn2(x)
        x = self.se_block(x, lens)
        return x + residual


class ECAPA_TDNN(torch.nn.Module):
    def __init__(
            self,
            feat_dim=80,
            emb_size=192,
            activation=nn.ReLU(inplace=True),
            channels=[512, 512, 512, 512, 1536],
            kernel_sizes=[5, 3, 3, 3, 1],
            dilations=[1, 2, 3, 4, 1],
            attention_channels=128,
            res2net_scale=8,
            se_channels=128,
            global_context=True,
            groups=[1, 1, 1, 1, 1],
    ):
        super().__init__()
        assert len(channels) == len(kernel_sizes)
        assert len(channels) == len(dilations)
        self.channels = channels
        self.blocks = nn.ModuleList()
        print('ECAPA_TDNN...')
        # The initial TDNN layer
        self.pre = TDNNBlock(
            feat_dim,
            channels[0],
            kernel_sizes[0],
            dilation=dilations[0],
            activation=activation,
            groups=groups[0],
        )

        # SE-Res2Net layers
        for i in range(1, len(channels) - 1):
            self.blocks.append(
                SERes2NetBlock(
                    channels[i - 1],
                    channels[i],
                    res2net_scale=res2net_scale,
                    se_channels=se_channels,
                    kernel_size=kernel_sizes[i],
                    dilation=dilations[i],
                    activation=activation,
                    groups=groups[i],
                )
            )

        # Multi-layer feature aggregation
        self.mfa = TDNNBlock(
            sum(channels[1:-1]),
            channels[-1],
            kernel_sizes[-1],
            dilation=dilations[-1],
            activation=activation,
            groups=groups[-1],
        )
        '''
        self.mfa = nn.Sequential(
            nn.Conv1d(
                in_channels=sum(channels[1:-1]),
                out_channels=channels[-1],
                kernel_size=kernel_sizes[-1],
                dilation=dilations[-1],
                groups=groups[-1]
            ),
            activation,
            #nn.BatchNorm1d(channels[-1])
        )
        '''

        # Attentive Statistical Pooling
        self.asp = AttentiveStatisticsPooling(
            channels[-1],
            attention_channels=attention_channels,
            global_context=global_context,
        )
        self.asp_bn = nn.BatchNorm1d(num_features=channels[-1] * 2)

        # Final linear transformation
        self.fc = nn.Linear(in_features=channels[-1] * 2, out_features=emb_size)

    def forward(self, x, lens=None):
        # Minimize transpose for efficiency
        #x = x.transpose(1, 2)

        x = self.pre(x)
        xs = []
        for i in range(len(self.blocks)):
            x = self.blocks[i](x, lens=lens)
            xs.append(x)
            
        # Multi-layer feature aggregation
        x = torch.cat(xs, dim=1)
        x = self.mfa(x)

        # Attentive Statistical Pooling
        x = self.asp(x, lens=lens)
        x = self.asp_bn(x)

        # Final linear transformation
        x = self.fc(x.squeeze(-1))
        return x