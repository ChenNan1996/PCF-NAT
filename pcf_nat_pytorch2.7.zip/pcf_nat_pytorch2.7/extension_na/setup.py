# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import os
import glob
from setuptools import find_packages, setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

#pip install --no-build-isolation -e .

import torch
capability = torch.cuda.get_device_capability()
print('torch.cuda.get_device_capability()=', capability)
capability = f'{capability[0]}.{capability[1]}'
print('capability=', capability)
os.environ['TORCH_CUDA_ARCH_LIST'] = capability#'8.6'

library_name = "na_cuda"
folder = "na_cuda"

if torch.__version__ >= "2.4.0":
    csrcfd = 'csrc_tc240_or_bigger'
else:
    csrcfd = 'csrc_tc201'

this_dir = os.path.dirname(os.path.curdir)
extensions_dir = os.path.join(this_dir, folder, csrcfd)
sources = list(glob.glob(os.path.join(extensions_dir, "*.cpp")))
cuda_sources = list(glob.glob(os.path.join(extensions_dir, "*.cu")))
sources += cuda_sources
#print('sources=', sources)
#sources = [f'{extensions_dir}/main.cpp', f'{extensions_dir}/fp16_ana1d.cu']#, f'{extensions_dir}/bf16_ana1d.cu'

setup(
    name=library_name,
    version="0.0.1",
    packages=find_packages(),
    ext_modules=[
        CUDAExtension(
                name=f"{library_name}._C",
                #name=library_name,
                sources=sources,
                extra_compile_args={'cxx': ['-g'],
                                    'nvcc': ['-O3']})
    ],
    #install_requires=["torch"],
    cmdclass={'build_ext': BuildExtension},
)
