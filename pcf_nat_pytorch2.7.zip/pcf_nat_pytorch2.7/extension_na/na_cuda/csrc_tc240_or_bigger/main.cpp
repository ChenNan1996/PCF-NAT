#include <Python.h>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>

extern "C" {
  /* Creates a dummy empty _C module that can be imported from Python.
     The import from Python will load the .so consisting of this file
     in this extension, so that the TORCH_LIBRARY static initializers
     below are run. */
  PyObject* PyInit__C(void)
  {
      static struct PyModuleDef module_def = {
          PyModuleDef_HEAD_INIT,
          "_C",   /* name of module */
          NULL,   /* module documentation, may be NULL */
          -1,     /* size of per-interpreter state of the module,
                     or -1 if the module keeps state in global variables. */
          NULL,   /* methods */
      };
      return PyModule_Create(&module_def);
  }
}

namespace na_cuda{

TORCH_LIBRARY(na_cuda, m) {
    m.def("bf16_ana_qk_forward(Tensor query, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_q_backward(Tensor attn_gd, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_av_forward
    m.def("bf16_ana_k_backward(Tensor attn_gd, Tensor query, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_av_forward(Tensor attn, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_attn_backward(Tensor result_gd, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_qk_forward
    m.def("bf16_ana_v_backward(Tensor attn, Tensor result_gd, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_k_backward
    
    m.def("fp16_ana_qk_forward(Tensor query, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_q_backward(Tensor attn_gd, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_av_forward
    m.def("fp16_ana_k_backward(Tensor attn_gd, Tensor query, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_av_forward(Tensor attn, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_attn_backward(Tensor result_gd, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_qk_forward
    m.def("fp16_ana_v_backward(Tensor attn, Tensor result_gd, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_k_backward
}

}