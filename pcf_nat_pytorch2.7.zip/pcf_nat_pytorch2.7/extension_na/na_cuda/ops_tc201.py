import torch
from torch import Tensor

class bf16_ANA1d_QK_Function(torch.autograd.Function):
    @staticmethod
    def forward(ctx, q, k, win_size, left):
        N, T, C = q.shape
        assert C%8==0
        attn = torch.ops.na_cuda.bf16_ana_qk_forward.default(q, k, N, T, C, win_size, left)
        ctx.save_for_backward(q, k)
        ctx.win_size = win_size
        ctx.left = left
        return attn
        
    @staticmethod
    def backward(ctx, attn_gd):
        assert attn_gd.dtype == torch.float32
        attn_gd = attn_gd.contiguous()
        q, k = ctx.saved_tensors
        N, T, C = q.shape
        q_gd = torch.ops.na_cuda.bf16_ana_q_backward.default(attn_gd, k,  N, T, C, ctx.win_size, ctx.left)
        k_gd = torch.ops.na_cuda.bf16_ana_k_backward.default(attn_gd, q,  N, T, C, ctx.win_size, ctx.left)
        return (q_gd, k_gd, None, None)
        
class bf16_ANA1d_AV_Function(torch.autograd.Function):
    @staticmethod
    def forward(ctx, attn, v, win_size, left):
        N, T, C = v.shape
        result = torch.ops.na_cuda.bf16_ana_av_forward.default(attn, v, N, T, C, win_size, left)
        ctx.save_for_backward(attn, v)
        ctx.win_size = win_size
        ctx.left = left
        return result
        
    @staticmethod
    def backward(ctx, result_gd):
        result_gd = result_gd.contiguous()
        N, T, C = result_gd.shape
        attn, v = ctx.saved_tensors
        assert result_gd.dtype==v.dtype
        attn_gd = torch.ops.na_cuda.bf16_ana_attn_backward.default(result_gd, v,  N, T, C, ctx.win_size, ctx.left)
        v_gd = torch.ops.na_cuda.bf16_ana_v_backward.default(attn, result_gd, N, T, C, ctx.win_size, ctx.left)
        return (attn_gd, v_gd, None, None)



class fp16_ANA1d_QK_Function(torch.autograd.Function):
    @staticmethod
    def forward(ctx, q, k, win_size, left):
        N, T, C = q.shape
        assert C%8==0
        attn = torch.ops.na_cuda.fp16_ana_qk_forward.default(q, k, N, T, C, win_size, left)
        ctx.save_for_backward(q, k)
        ctx.win_size = win_size
        ctx.left = left
        return attn
        
    @staticmethod
    def backward(ctx, attn_gd):
        assert attn_gd.dtype == torch.float32
        attn_gd = attn_gd.contiguous()
        q, k = ctx.saved_tensors
        N, T, C = q.shape
        q_gd = torch.ops.na_cuda.fp16_ana_q_backward.default(attn_gd, k,  N, T, C, ctx.win_size, ctx.left)
        k_gd = torch.ops.na_cuda.fp16_ana_k_backward.default(attn_gd, q,  N, T, C, ctx.win_size, ctx.left)
        return (q_gd, k_gd, None, None)
        
class fp16_ANA1d_AV_Function(torch.autograd.Function):
    @staticmethod
    def forward(ctx, attn, v, win_size, left):
        N, T, C = v.shape
        result = torch.ops.na_cuda.fp16_ana_av_forward.default(attn, v, N, T, C, win_size, left)
        ctx.save_for_backward(attn, v)
        ctx.win_size = win_size
        ctx.left = left
        return result
        
    @staticmethod
    def backward(ctx, result_gd):
        result_gd = result_gd.contiguous()
        N, T, C = result_gd.shape
        attn, v = ctx.saved_tensors
        assert result_gd.dtype==v.dtype
        attn_gd = torch.ops.na_cuda.fp16_ana_attn_backward.default(result_gd, v,  N, T, C, ctx.win_size, ctx.left)
        v_gd = torch.ops.na_cuda.fp16_ana_v_backward.default(attn, result_gd, N, T, C, ctx.win_size, ctx.left)
        return (attn_gd, v_gd, None, None)



def ana_qk(q: Tensor, k: Tensor, win_size: int, left: int) -> Tensor:
    assert q.is_contiguous()
    assert k.is_contiguous()
    assert q.dtype==k.dtype
    
    attn = None
    if q.dtype==torch.bfloat16:
        attn = bf16_ANA1d_QK_Function.apply(q, k, win_size, left)
    elif q.dtype==torch.float16:
        attn = fp16_ANA1d_QK_Function.apply(q, k, win_size, left)
    else:
        assert False, 'query.dtype and key.dtype should be bf16 or fp16'
    return attn

def ana_av(attn: Tensor, v: Tensor, win_size: int, left: int) -> Tensor:
    assert attn.is_contiguous()
    assert v.is_contiguous()
    assert attn.dtype==torch.float32
    
    result = None
    if v.dtype==torch.bfloat16:
        result = bf16_ANA1d_AV_Function.apply(attn, v, win_size, left)
    elif v.dtype==torch.float16:
        result = fp16_ANA1d_AV_Function.apply(attn, v, win_size, left)
    else:
        assert False, 'value.dtype should be bf16 or fp16'
    return result