#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_bf16.h>

at::Tensor bf16_ana_qk_forward(const at::Tensor& query,
                 const at::Tensor& key,
                 const int64_t N,
                 const int64_t T,
                 const int64_t C,
                 const int64_t win_size,
                 const int64_t left);

at::Tensor bf16_ana_av_forward(const at::Tensor& attn,
                 const at::Tensor& value,
                 const int64_t N,
                 const int64_t T,
                 const int64_t C,
                 const int64_t win_size,
                 const int64_t left);

at::Tensor bf16_ana_v_backward(const at::Tensor& attn,
                 const at::Tensor& result_gd,
                 const int64_t N,
                 const int64_t T,
                 const int64_t C,
                 const int64_t win_size,
                 const int64_t left);