#include <Python.h>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>

#include "bf16_ana1d.h"
#include "fp16_ana1d.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("bf16_ana_qk_forward",
          &bf16_ana_qk_forward,
          "bf16_ana_qk_forward kernel warpper");
    m.def("bf16_ana_q_backward",
          &bf16_ana_av_forward,
          "bf16_ana_q_backward kernel warpper");
    m.def("bf16_ana_k_backward",
          &bf16_ana_v_backward,
          "bf16_ana_k_backward kernel warpper");
    m.def("bf16_ana_av_forward",
          &bf16_ana_av_forward,
          "bf16_ana_av_forward kernel warpper");
    m.def("bf16_ana_attn_backward",
          &bf16_ana_qk_forward,
          "bf16_ana_attn_backward kernel warpper");
    m.def("bf16_ana_v_backward",
          &bf16_ana_v_backward,
          "bf16_ana_v_backward kernel warpper");

    m.def("fp16_ana_qk_forward",
          &fp16_ana_qk_forward,
          "fp16_ana_qk_forward kernel warpper");
    m.def("fp16_ana_q_backward",
          &fp16_ana_av_forward,
          "fp16_ana_q_backward kernel warpper");
    m.def("fp16_ana_k_backward",
          &fp16_ana_v_backward,
          "fp16_ana_k_backward kernel warpper");
    m.def("fp16_ana_av_forward",
          &fp16_ana_av_forward,
          "fp16_ana_av_forward kernel warpper");
    m.def("fp16_ana_attn_backward",
          &fp16_ana_qk_forward,
          "fp16_ana_attn_backward kernel warpper");
    m.def("fp16_ana_v_backward",
          &fp16_ana_v_backward,
          "fp16_ana_v_backward kernel warpper");
}

TORCH_LIBRARY(na_cuda, m) {
    m.def("bf16_ana_qk_forward(Tensor query, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_q_backward(Tensor attn_gd, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_av_forward
    m.def("bf16_ana_k_backward(Tensor attn_gd, Tensor query, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_av_forward(Tensor attn, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("bf16_ana_attn_backward(Tensor result_gd, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_qk_forward
    m.def("bf16_ana_v_backward(Tensor attn, Tensor result_gd, int N, int T, int C, int win_size, int left) -> Tensor");//bf16_ana_k_backward
    
    m.def("fp16_ana_qk_forward(Tensor query, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_q_backward(Tensor attn_gd, Tensor key, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_av_forward
    m.def("fp16_ana_k_backward(Tensor attn_gd, Tensor query, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_av_forward(Tensor attn, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");
    m.def("fp16_ana_attn_backward(Tensor result_gd, Tensor value, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_qk_forward
    m.def("fp16_ana_v_backward(Tensor attn, Tensor result_gd, int N, int T, int C, int win_size, int left) -> Tensor");//fp16_ana_k_backward
}

TORCH_LIBRARY_IMPL(na_cuda, CUDA, m) {
  m.impl("bf16_ana_qk_forward", &bf16_ana_qk_forward);
  m.impl("bf16_ana_q_backward", &bf16_ana_av_forward);
  m.impl("bf16_ana_k_backward", &bf16_ana_v_backward);
  m.impl("bf16_ana_av_forward", &bf16_ana_av_forward);
  m.impl("bf16_ana_attn_backward", &bf16_ana_qk_forward);
  m.impl("bf16_ana_v_backward", &bf16_ana_v_backward);

  m.impl("fp16_ana_qk_forward", &fp16_ana_qk_forward);
  m.impl("fp16_ana_q_backward", &fp16_ana_av_forward);
  m.impl("fp16_ana_k_backward", &fp16_ana_v_backward);
  m.impl("fp16_ana_av_forward", &fp16_ana_av_forward);
  m.impl("fp16_ana_attn_backward", &fp16_ana_qk_forward);
  m.impl("fp16_ana_v_backward", &fp16_ana_v_backward);
}