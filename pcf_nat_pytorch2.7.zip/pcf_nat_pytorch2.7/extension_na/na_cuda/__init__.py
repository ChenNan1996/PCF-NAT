import torch
from pathlib import Path
from . import _C

print(torch.__version__)
if torch.__version__ >= "2.4.0":
    from . import ops_tc240_or_bigger as ops
    print('ops_tc240_or_bigger')
else:
    from . import ops_tc201 as ops
    print('ops_tc201')