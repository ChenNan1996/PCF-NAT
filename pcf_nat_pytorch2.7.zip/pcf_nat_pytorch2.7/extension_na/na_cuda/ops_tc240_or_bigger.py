import torch
from torch import Tensor

__all__ = ["bf16_ana_qk_forward", "bf16_ana_av_forward", "fp16_ana_qk_forward", "fp16_ana_av_forward"]

# qk, av
# bf16_qk: register_fake, backward, setup_context
# bf16_av: register_fake, backward, setup_context
# bf16 & backward & register_fake: attn, v, q, k
#
# fp16_qk: register_fake, backward, setup_context
# fp16_av: register_fake, backward, setup_context
# fp16 & backward & register_fake: attn, v, q, k

def ana_qk(q: Tensor, k: Tensor, win_size: int, left: int) -> Tensor:
    assert q.is_contiguous()
    assert k.is_contiguous()
    assert q.dtype==k.dtype
    N, T, C = q.shape
    #attn = torch.empty((N,T,win_size), dtype=torch.float32, device=q.device)
    attn = None
    if q.dtype==torch.bfloat16:
        attn = torch.ops.na_cuda.bf16_ana_qk_forward.default(q, k, N, T, C, win_size, left)
    elif q.dtype==torch.float16:
        attn = torch.ops.na_cuda.fp16_ana_qk_forward.default(q, k, N, T, C, win_size, left)
    else:
        assert False, 'query.dtype and key.dtype should be bf16 or fp16'
    return attn

def ana_av(attn: Tensor, v: Tensor, win_size: int, left: int) -> Tensor:
    assert attn.is_contiguous()
    assert v.is_contiguous()
    assert attn.dtype==torch.float32
    
    N, T, C = v.shape
    #result = torch.empty(v.shape, dtype=v.dtype, device=v.device)
    result = None
    if v.dtype==torch.bfloat16:
        result = torch.ops.na_cuda.bf16_ana_av_forward.default(attn, v, N, T, C, win_size, left)
    elif v.dtype==torch.float16:
        result = torch.ops.na_cuda.fp16_ana_av_forward.default(attn, v, N, T, C, win_size, left)
    else:
        assert False, 'value.dtype should be bf16 or fp16'
    return result


# Registers a FakeTensor kernel (aka "meta kernel", "abstract impl")
# that describes what the properties of the output Tensor are given
# the properties of the input Tensor. The FakeTensor kernel is necessary
# for the op to work performantly with torch.compile.
@torch.library.register_fake("na_cuda::bf16_ana_qk_forward")
def _bf16_qk(q, k, N, T, C, win_size, left):
    torch._check(q.is_contiguous())
    torch._check(k.is_contiguous())
    
    torch._check(q.dtype == torch.bfloat16)
    torch._check(k.dtype == torch.bfloat16)
    
    torch._check(q.device == k.device)
    
    attn = torch.empty((N,T,win_size), dtype=torch.float32, device=q.device)
    return attn


def bf16_qk_backward(ctx, attn_gd):
    #print('--------------backward1--------------------')
    assert attn_gd.dtype == torch.float32
    attn_gd = attn_gd.contiguous()
    
    q, k = ctx.saved_tensors
    N, T, C = q.shape
    #q_gd = torch.empty(q.shape, dtype=q.dtype, device=attn_gd.device)
    q_gd = torch.ops.na_cuda.bf16_ana_q_backward(attn_gd, k,  N, T, C, ctx.win_size, ctx.left)
    #k_gd = torch.empty(k.shape, dtype=k.dtype, device=attn_gd.device)
    k_gd = torch.ops.na_cuda.bf16_ana_k_backward(attn_gd, q,  N, T, C, ctx.win_size, ctx.left)
    return (q_gd, k_gd, None, None, None, None, None)
    
def bf16_qk_setup_context(ctx, inputs, output):
    q, k, N, T, C, win_size, left = inputs
    ctx.win_size = win_size
    ctx.left = left
    ctx.save_for_backward(q, k)

# This adds training support for the operator. You must provide us
# the backward formula for the operator and a `setup_context` function
# to save values to be used in the backward.
torch.library.register_autograd("na_cuda::bf16_ana_qk_forward", bf16_qk_backward, setup_context=bf16_qk_setup_context)


@torch.library.register_fake("na_cuda::bf16_ana_av_forward")
def _bf16_av(attn, v, N, T, C, win_size, left):
    torch._check(attn.is_contiguous())
    torch._check(v.is_contiguous())
    
    torch._check(attn.dtype == torch.float32)
    torch._check(v.dtype == torch.bfloat16)
    
    torch._check(attn.device == v.device)
    
    result = torch.empty(v.shape, dtype=v.dtype, device=v.device)
    return result


def bf16_av_backward(ctx, result_gd):
    #print('--------------backward2--------------------')
    assert result_gd.dtype == torch.bfloat16
    result_gd = result_gd.contiguous()
    
    attn, v = ctx.saved_tensors
    N, T, C = result_gd.shape
    #attn_gd = torch.empty(attn.shape, dtype=attn.dtype, device=result_gd.device)
    attn_gd = torch.ops.na_cuda.bf16_ana_attn_backward(result_gd, v,  N, T, C, ctx.win_size, ctx.left)
    #v_gd = torch.empty(v.shape, dtype=v.dtype, device=result_gd.device)
    v_gd = torch.ops.na_cuda.bf16_ana_v_backward(attn, result_gd,  N, T, C, ctx.win_size, ctx.left)
    return (attn_gd, v_gd, None, None, None, None, None)
    
def bf16_av_setup_context(ctx, inputs, output):
    attn, v, N, T, C, win_size, left = inputs
    ctx.win_size = win_size
    ctx.left = left
    ctx.save_for_backward(attn, v)

torch.library.register_autograd("na_cuda::bf16_ana_av_forward", bf16_av_backward, setup_context=bf16_av_setup_context)


@torch.library.register_fake("na_cuda::bf16_ana_attn_backward")
def _attn(result_gd, v, N, T, C, win_size, left):
    torch._check(result_gd.is_contiguous())
    torch._check(v.is_contiguous())
    
    torch._check(result_gd.dtype == torch.bfloat16)
    torch._check(v.dtype == torch.bfloat16)
    
    torch._check(result_gd.device == v.device)
    
    attn_gd = torch.empty((N,T,win_size), dtype=torch.float32, device=v.device)
    return attn_gd
    
@torch.library.register_fake("na_cuda::bf16_ana_v_backward")
def _v(attn, result_gd, N, T, C, win_size, left):
    torch._check(attn.is_contiguous())
    torch._check(result_gd.is_contiguous())
    
    torch._check(attn.dtype == torch.float32)
    torch._check(result_gd.dtype == torch.bfloat16)
    
    torch._check(attn.device == result_gd.device)
    
    v_gd = torch.empty((N,T,C), dtype=result_gd.dtype, device=result_gd.device)
    return v_gd

@torch.library.register_fake("na_cuda::bf16_ana_q_backward")
def _q(attn_gd, k, N, T, C, win_size, left):
    torch._check(attn_gd.is_contiguous())
    torch._check(k.is_contiguous())
    
    torch._check(attn_gd.dtype == torch.float32)
    torch._check(k.dtype == torch.bfloat16)
    
    torch._check(attn_gd.device == k.device)
    
    q_gd = torch.empty(k.shape, dtype=k.dtype, device=k.device)
    return q_gd
    
@torch.library.register_fake("na_cuda::bf16_ana_k_backward")
def _k(attn_gd, q, N, T, C, win_size, left):
    torch._check(attn_gd.is_contiguous())
    torch._check(q.is_contiguous())
    
    torch._check(attn_gd.dtype == torch.float32)
    torch._check(q.dtype == torch.bfloat16)
    
    torch._check(attn_gd.device == q.device)
    
    k_gd = torch.empty(q.shape, dtype=q.dtype, device=q.device)
    return k_gd


###### below: fp16 ###############################################################################################################################################


@torch.library.register_fake("na_cuda::fp16_ana_qk_forward")
def _fp16_qk(q, k, N, T, C, win_size, left):
    torch._check(q.is_contiguous())
    torch._check(k.is_contiguous())
    
    torch._check(q.dtype == torch.float16)
    torch._check(k.dtype == torch.float16)
    
    torch._check(q.device == k.device)
    
    attn = torch.empty((N,T,win_size), dtype=torch.float32, device=q.device)
    return attn


def fp16_qk_backward(ctx, attn_gd):
    assert attn_gd.dtype == torch.float32
    attn_gd = attn_gd.contiguous()
    
    q, k = ctx.saved_tensors
    N, T, C = q.shape
    q_gd = torch.ops.na_cuda.fp16_ana_q_backward(attn_gd, k,  N, T, C, ctx.win_size, ctx.left)
    k_gd = torch.ops.na_cuda.fp16_ana_k_backward(attn_gd, q,  N, T, C, ctx.win_size, ctx.left)
    return (q_gd, k_gd, None, None, None, None, None)
    
def fp16_qk_setup_context(ctx, inputs, output):
    q, k, N, T, C, win_size, left = inputs
    ctx.win_size = win_size
    ctx.left = left
    ctx.save_for_backward(q, k)

torch.library.register_autograd("na_cuda::fp16_ana_qk_forward", fp16_qk_backward, setup_context=fp16_qk_setup_context)



@torch.library.register_fake("na_cuda::fp16_ana_av_forward")
def _fp16_av(attn, v, N, T, C, win_size, left):
    torch._check(attn.is_contiguous())
    torch._check(v.is_contiguous())
    
    torch._check(attn.dtype == torch.float32)
    torch._check(v.dtype == torch.float16)
    
    torch._check(attn.device == v.device)
    
    result = torch.empty(v.shape, dtype=v.dtype, device=v.device)
    return result


def fp16_av_backward(ctx, result_gd):
    #print('--------------backward2--------------------')
    assert result_gd.dtype == torch.float16
    result_gd = result_gd.contiguous()
    
    attn, v = ctx.saved_tensors
    N, T, C = result_gd.shape
    attn_gd = torch.ops.na_cuda.fp16_ana_attn_backward(result_gd, v,  N, T, C, ctx.win_size, ctx.left)
    v_gd = torch.ops.na_cuda.fp16_ana_v_backward(attn, result_gd,  N, T, C, ctx.win_size, ctx.left)
    return (attn_gd, v_gd, None, None, None, None, None)
    
def fp16_av_setup_context(ctx, inputs, output):
    attn, v, N, T, C, win_size, left = inputs
    ctx.win_size = win_size
    ctx.left = left
    ctx.save_for_backward(attn, v)

torch.library.register_autograd("na_cuda::fp16_ana_av_forward", fp16_av_backward, setup_context=fp16_av_setup_context)


@torch.library.register_fake("na_cuda::fp16_ana_attn_backward")
def _attn(result_gd, v, N, T, C, win_size, left):
    torch._check(result_gd.is_contiguous())
    torch._check(v.is_contiguous())
    
    torch._check(result_gd.dtype == torch.float16)
    torch._check(v.dtype == torch.float16)
    
    torch._check(result_gd.device == v.device)
    
    attn_gd = torch.empty((N,T,win_size), dtype=torch.float32, device=v.device)
    return attn_gd
    
@torch.library.register_fake("na_cuda::fp16_ana_v_backward")
def _v(attn, result_gd, N, T, C, win_size, left):
    torch._check(attn.is_contiguous())
    torch._check(result_gd.is_contiguous())
    
    torch._check(attn.dtype == torch.float32)
    torch._check(result_gd.dtype == torch.float16)
    
    torch._check(attn.device == result_gd.device)
    
    v_gd = torch.empty((N,T,C), dtype=result_gd.dtype, device=result_gd.device)
    return v_gd

@torch.library.register_fake("na_cuda::fp16_ana_q_backward")
def _q(attn_gd, k, N, T, C, win_size, left):
    torch._check(attn_gd.is_contiguous())
    torch._check(k.is_contiguous())
    
    torch._check(attn_gd.dtype == torch.float32)
    torch._check(k.dtype == torch.float16)
    
    torch._check(attn_gd.device == k.device)
    
    q_gd = torch.empty(k.shape, dtype=k.dtype, device=k.device)
    return q_gd
    
@torch.library.register_fake("na_cuda::fp16_ana_k_backward")
def _k(attn_gd, q, N, T, C, win_size, left):
    torch._check(attn_gd.is_contiguous())
    torch._check(q.is_contiguous())
    
    torch._check(attn_gd.dtype == torch.float32)
    torch._check(q.dtype == torch.float16)
    
    torch._check(attn_gd.device == q.device)
    
    k_gd = torch.empty(q.shape, dtype=q.dtype, device=q.device)
    return k_gd