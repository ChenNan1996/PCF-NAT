import torch
import na_cuda

import numpy as np
import random
def set_random_seed(seed):
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
set_random_seed(2025)

dtype = torch.bfloat16
device = 'cuda'
'''
N = 512
T = 200
C = 256
num_heads = 16
head_dim = 16
win_size = 27
left = win_size//2

x = torch.randn((N, T, 3, num_heads, head_dim), dtype=dtype, device=device)
x0 = torch.stack([x[0]], dim=0)
x = x.permute(2,0,3,1,4).contiguous() # ( 3, N, num_heads, T, head_dim )
x = x.view(3, N*num_heads, T, head_dim)
q, k, v = x[0], x[1], x[2]
attn = na_cuda.ops.ana_qk(q, k, win_size, left)
result = na_cuda.ops.ana_av(attn, v, win_size, left)
result = result.view(N,num_heads,T,head_dim)
result = result.transpose(1,2).contiguous().view(N,T,C)

rs0 = result[0]
print(rs0)

#set_random_seed(2025)
N = 1
#x = torch.randn((N, T, 3, num_heads, head_dim), dtype=dtype, device=device)
x = x0
x = x.permute(2,0,3,1,4).contiguous() # ( 3, N, num_heads, T, head_dim )
x = x.view(3, N*num_heads, T, head_dim)
q, k, v = x[0], x[1], x[2]
attn = na_cuda.ops.ana_qk(q, k, win_size, left)
result = na_cuda.ops.ana_av(attn, v, win_size, left)
result = result.view(N,num_heads,T,head_dim)
result = result.transpose(1,2).contiguous().view(N,T,C)
print(result[0])

print(result[0]-rs0)
print(torch.sum(result[0]-rs0))
'''
import torch.nn as nn
import torch.nn.functional as F
class TDNNBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding='same', dilation=1, groups=1, bias=True, activation=nn.ReLU(inplace=True), norm_layer=nn.BatchNorm1d):
        super().__init__()
        assert padding != 'same' or stride==1
        self.conv = nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.activation = activation
        self.norm = norm_layer(out_channels)

    def forward(self, x):
        return self.norm(self.activation(self.conv(x)))

class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
        
N = 128
T = 300
C = 1024
set_random_seed(2025)
model = torch.nn.Linear(1024, 256)#, dtype=dtype
#model = TDNNBlock(C, C, 1)
#model = Mlp(in_features=C, hidden_features=1024, act_layer=nn.GELU, drop=0)
#model = nn.Conv1d(in_channels=1024, out_channels=256, kernel_size=1)
model.to(device)
model.eval()
x = torch.randn((N, T, C), dtype=dtype, device=device)
#x0 = torch.stack([x[0]], dim=0)
with torch.no_grad():
    with torch.autocast(device_type=device, dtype=dtype):
        #x = x.transpose(1, 2)
        y = model(x)
        y0 = model(x[0:1])
        print(y[0]-y0)
        print(torch.sum(y[0]-y0))









